gRPC Bank Application written in Java
This is a maven project for eclipse.
Use Maven - Update Project to download dependencies and compile.
Run java server (BankServer) and client (BankClient) as java applications. 

On some systems it may be necessary to set the <os.detected.classifier> in the pom.xml file.
You can do it by adding, e.g.,
<os.detected.classifier>windows-x86_64</os.detected.classifier>