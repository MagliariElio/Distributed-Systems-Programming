Bank application implemented in Node.
(note that the implementation has to be refined, e.g. by completing the error management part) 
How to run example:
- extract archive
- open folder with visual studio code
- run npm install from terminal in folder
- now it should be possible to run server and client with the launch configurations

