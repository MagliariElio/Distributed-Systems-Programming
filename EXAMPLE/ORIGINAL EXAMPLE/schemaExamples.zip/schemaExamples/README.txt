This folder contains the examples discussed in the lecture about JSON schemas
