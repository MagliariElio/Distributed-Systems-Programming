WebSocket example: simple chat

index.html      main page of the application
main.js         javascript code of the client side of the application
style.css       css style for the application
server.js       server side of the application
package.json    dependencies

How to run the server:
1. open a terminal in the project directory
2. give the command for the installation of the dependencies:
npm install
3. run the server:
node server.js

How to run the client:
load the index.html in your browser
