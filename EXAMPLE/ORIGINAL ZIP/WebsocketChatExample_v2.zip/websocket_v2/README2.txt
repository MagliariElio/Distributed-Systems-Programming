WebSocket example: simple chat version 2

index2.html     main page of the application
main2.js        javascript code of the client side of the application
style.css       css style for the application
server2.js      server side of the application
package.json    dependencies

How to run the server:
1. open a terminal in the project directory
2. give the command for the installation of the dependencies:
npm install
3. run the server:
node server2.js

How to run the client:
load the index2.html in your browser
