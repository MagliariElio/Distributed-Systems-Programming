Distributed Systems programming
Examples of socket programming presented in the lectures
Package it.polito.dsp.echo.v0	version 0 (without error management)
Package it.polito.dsp.echo.v1	version 1 (including timeouts and error management)

