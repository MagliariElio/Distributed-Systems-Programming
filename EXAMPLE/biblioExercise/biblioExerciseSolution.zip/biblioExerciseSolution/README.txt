This folder contains the text and two possible solutions of the 
bibliography exercise about designing JSON schemas:
biblioschema.json		schema (first solution)
biblio.json			JSON sample file (first solution)
biblioschema_v2.json		schema (second solution)
biblio_v2.json			JSON sample file (second solution)
